-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 27, 2020 at 11:35 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `brainster_employ`
--

-- --------------------------------------------------------

--
-- Table structure for table `academy`
--

CREATE TABLE `academy` (
  `id` int(11) NOT NULL,
  `academy_courses` varchar(50) DEFAULT NULL,
  `created_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `academy`
--

INSERT INTO `academy` (`id`, `academy_courses`, `created_at`) VALUES
(1, 'Design', '2010-12-06'),
(2, 'Programing', '2011-10-05'),
(3, 'Marketing', '2009-05-12'),
(4, 'Datascience', '2012-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `id` int(11) NOT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `start` date DEFAULT NULL,
  `gpa` float DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `academy_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`id`, `first_name`, `last_name`, `start`, `gpa`, `email`, `academy_id`) VALUES
(1, 'Dania', 'Trowsdale', '2019-01-06', 9.8, 'dtrowsdaller@newsvine.com', 4),
(2, 'Juliet', 'Stansbie', '2017-05-06', 9, 'jastanbierm@googl.de', 1),
(3, 'Griffith', 'Minor', '2020-01-12', 8.5, 'gminor@webeden.co', 3),
(4, 'Suki', 'Link', '2018-05-05', 10, 'slinkq@webeden.co.uk', 2),
(5, 'Billie', 'Daal', '2019-05-01', 8.8, 'bdaalrg@wikispaces.com', 2),
(6, 'Egon', 'Daal', '2020-05-01', 8.6, 'edaalrg@wikispaces.com', 4),
(7, 'Alexine', 'Heinz', '2018-04-11', 9.6, 'aheinz@google.com', 3),
(8, 'Leeanne', 'Heinz', '2018-04-11', 9.6, 'lheinz@webeden.com', 1),
(9, 'Deborah', 'Atger', '2019-01-11', 10, 'datgerrn@blogtalk.co', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_data`
--

CREATE TABLE `user_data` (
  `id` int(11) NOT NULL,
  `costumer_name` varchar(30) DEFAULT NULL,
  `company_name` varchar(60) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `contact_email` varchar(40) DEFAULT NULL,
  `selected_academy_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_data`
--

INSERT INTO `user_data` (`id`, `costumer_name`, `company_name`, `contact_number`, `contact_email`, `selected_academy_id`) VALUES
(1, NULL, 'Apple', '00490105045265', 'apple.webtalk.com', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academy`
--
ALTER TABLE `academy`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `academy_id` (`academy_id`);

--
-- Indexes for table `user_data`
--
ALTER TABLE `user_data`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contact_email` (`contact_email`),
  ADD KEY `selected_academy_id` (`selected_academy_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academy`
--
ALTER TABLE `academy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `user_data`
--
ALTER TABLE `user_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `students`
--
ALTER TABLE `students`
  ADD CONSTRAINT `students_ibfk_1` FOREIGN KEY (`academy_id`) REFERENCES `academy` (`id`);

--
-- Constraints for table `user_data`
--
ALTER TABLE `user_data`
  ADD CONSTRAINT `user_data_ibfk_1` FOREIGN KEY (`selected_academy_id`) REFERENCES `academy` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
